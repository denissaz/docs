Evolution CMS  Docs
=========

Документация по Evolution CMS

Разработка мануала сообща через pull-requests + issues.

Автоматический билд после вливания в мастер на сайт.
