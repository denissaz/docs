Полезные ссылки
-------------------------

[MODX.im](http://modx.im)  - Сообщество по MODX

[code.divandesign.ru](http://code.divandesign.ru) - Репозиторий студии «Диван.Дизайн».

[Telegram](https://t.me/evolutioncms) - канал Evolution CMS в Телеграм
