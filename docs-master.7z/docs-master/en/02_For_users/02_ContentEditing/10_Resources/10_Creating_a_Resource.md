Creating a new document / resource
To add new sides / pages to the website you need to do the following:

In the Admin menu click on New Resource



You can also right click on a menu item and select "Create Resource Here".


A new "empty" document will appear



Modify the fields in the documents "Settings" tab where applicable and add your content to the resource content area, via the editor.



In the "General" tab, select the location where the new document should be saved to, by clicking on the Resource parent folder icon



The folder icon will change its appearance when clicked, it will "open", now click on any document in the main document tree.

Once clicked, the parent (ID + Name) will be displayed in the resource parent field.



Note:
If you right-clicked in the "Document Tree" to create the document, the document will already have the parent resource information in it

When you are finished modifying the document / resource, click "Save" to save the new resource