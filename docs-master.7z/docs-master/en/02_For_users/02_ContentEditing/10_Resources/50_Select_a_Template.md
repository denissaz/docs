After you create a web page, check that the correct template is in use.

Click on the document in the menu tree that you wish to edit:



Click the "Edit" button and go to the Generel tab.



A template will already be selected - this is the default setting, as set in the system configuration.

Select the template in the "Uses template" dropdown menu. The page will refresh to include any Template Variables assigned to the new template, but the document is not yet saved.



Once the correct template has been selected you can click on Save in the Action buttons.

