Edit a Resource
Editing an Existing Document
Click on the document in the document tree. A page summary will appear in the right hand panel.



If your site has been configured to do so, you will also see a Preview of the page so you can check that you have found the correct page.

Editing the document's content
Click on the document that you wish to edit and then click "Edit" in the Action icons.



Once you have clicked the edit button, the page will refresh and you will now have something like this.



You can now use the WYSIWYG editor to edit the page content.



Once you have finished click Save.