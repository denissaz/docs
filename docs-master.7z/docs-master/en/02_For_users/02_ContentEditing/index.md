This guide is designed to assist editors in using the Evo CMS website.

This guide should be used in conjunction with the Evo Administrator's Guide, which covers more advanced topics such as

Backing up
Creating users
Creating secure areas
In preparing this guide we have presumed that your web developer has already configured the basic setup for your website.

Accordingly, we deal with the basic administration issues you are likely to face in the order in which they are likely to occur.