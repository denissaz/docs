http://www.evolution-docs.com/documentation/designing/adding-tags/resource-fields
need copy this