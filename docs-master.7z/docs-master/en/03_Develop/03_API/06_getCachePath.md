###Возвращает относительный путь до папки для кэширования

string getCachePath();

***

####Пример

````php
echo $modx->getCachePath();
// полученный результат: /assets/cache/
````
