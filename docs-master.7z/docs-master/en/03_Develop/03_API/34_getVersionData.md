###Возвращает информацию о версии MODx

array getVersionData();

***

####Пример

	$txt = $modx->getVersionData();
	//вернет информацию о версии MODX.