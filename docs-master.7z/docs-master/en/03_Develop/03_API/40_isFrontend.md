###Если страница формируется в пользовательской части (frontend), то функция возвращает true, иначе false

bool isFrontend();

Смотрите также: isBackend(), insideManager()