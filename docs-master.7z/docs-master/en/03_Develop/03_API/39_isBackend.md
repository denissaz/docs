###Если страница формируется в системе управления (backend), то функция возвращает true, иначе false

bool isBackend();

Смотрите также: isFrontend(), insideManager()