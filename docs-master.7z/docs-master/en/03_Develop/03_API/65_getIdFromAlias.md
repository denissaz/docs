Returns the ID of the document by URL
```
string getIdFromAlias(string $alias);
```
**$alias** - document alias

### Пример
```
	$id = $modx->getIdFromAlias('folder/folder/doc.html')
```
