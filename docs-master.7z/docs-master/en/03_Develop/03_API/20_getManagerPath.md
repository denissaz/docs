###Возвращает относительный путь до директории менеджера

string getManagerPath();

***

####Пример

	echo $modx->getManagerPath(); 
	// полученный результат: /manager/