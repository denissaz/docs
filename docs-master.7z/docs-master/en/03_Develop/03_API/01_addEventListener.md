###Add an event handler for the plugin

Note: This is used only for the current execution cycle.

string addEventListener(string $evtName, string $pluginName);

$evtName - event name
$pluginName - name of the plugin
