###Размещение заданного кода HTML в область ‹head›

string regClientStartupHTMLBlock(string $html);

**$html** - HTML-код для размещения