###Размещение заданного HTML-кода в конец документа

string regClientHTMLBlock(string $html);

**$html** - HTML код для размещения