###Идентификатор текущего ресурса

int documentIdentifier

Содержит ID документа на котором был вызван код.

####Пример

    <?php  echo "ID ресурса: " . $modx->documentIdentifier;  ?>