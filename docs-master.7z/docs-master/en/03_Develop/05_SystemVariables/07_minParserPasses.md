###Минимальное количество проходов парсера

int minParserPasses

Содержит минимальное число проходов парсером.

####Пример

    <?php  echo $modx->minParserPasses;  ?>