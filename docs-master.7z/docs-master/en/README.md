Evolution CMS Docs
=========

Evolution CMS documentation

Development of the manual through pull-requests + issues.

Automatic build on the site after merge into the master.
