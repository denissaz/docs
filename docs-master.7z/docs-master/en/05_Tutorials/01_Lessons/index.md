<h2 style=margin-top:0px>Уроки</h2>
<p>Для тех кто только знакомится с MODX EVO очень рекомендую пройтись по ссылкам ниже, сразу отпадут многие вопросы.</p>
<h3>Видео уроки по созданию сайта на MODX EVO</h3>
<ul>
<li><a href="http://vimeo.com/29422796">Видео урок</a>&nbsp; (<a style="line-height: 1.5;" href="http://a42.ru/site/tutorial-cash.html">доп материалы и ссылки с видео</a>)</li>
<li><a href="http://www.youtube.com/watch?v=WDBsCL9Xfx8">Видео урок 2</a></li>
</ul>
<h3>Уроки с сайта Я--гу.ру</h3>
<ul class="unstyled sidebarPadding scroll-pane">
<li><a title="Сайт за один день? Это реально!" href="http://i--gu.ru/vstuplenie">Вступление - Сайт за один день? Это реально!</a></li>
<li><a title="Установка локального сервера XAMPP" href="http://i--gu.ru/urok-1">Урок 1 - Установка локального сервера XAMPP</a></li>
<li><a title="Установка MODx Evolution" href="http://i--gu.ru/urok-2">Урок 2 - Установка MODx Evolution</a></li>
<li><a title="Знакомство с MODx Evolution" href="http://i--gu.ru/urok-3">Урок 3 - Знакомство с MODx Evolution</a></li>
<li><a title="Интеграция шаблона в MODx. Разбиение на чанки" href="http://i--gu.ru/urok-4">Урок 4 - Интеграция шаблона в MODx. Разбиение на чанки</a></li>
<li><a title="Создание динамического меню в MODx" href="http://i--gu.ru/urok-5">Урок 5 - Создание динамического меню в MODx</a></li>
<li><a title="Изменяем шапку сайта, чанк HEADER" href="http://i--gu.ru/urok-6">Урок 6 - Изменяем шапку сайта, чанк HEADER</a></li>
<li><a title="Редактируем чанк COLUMN" href="http://i--gu.ru/urok-7">Урок 7 - Редактируем чанк COLUMN</a></li>
<li><a title="Редактируем чанк WRAPPER и FOOTER" href="http://i--gu.ru/urok-8">Урок 8 - Редактируем чанк WRAPPER и FOOTER</a></li>
<li><a title="Выводим галерею с помощью сниппета Ditto" href="http://i--gu.ru/urok-9">Урок 9 - Выводим галерею с помощью сниппета Ditto</a></li>
<li><a title="Делаем новостную ленту" href="http://i--gu.ru/urok-10">Урок 10 - Делаем новостную ленту</a></li>
<li><a title="Настраиваем блог. Система комментариев DISQUS" href="http://i--gu.ru/urok-11">Урок 11 - Настраиваем блог. Система комментариев DISQUS</a></li>
<li><a title="Форма обратной связи. Сниппет eForm" href="http://i--gu.ru/urok-12">Урок 12 - Форма обратной связи. Сниппет eForm</a></li>
<li><a title="Перенос сайта на хостинг" href="http://i--gu.ru/urok-13">Урок 13 - Перенос сайта на хостинг</a></li>
<li><a title="Общие итоги курса. Дальнейшие рекомендации." href="http://i--gu.ru/zaklyuchenie">Заключение - Общие итоги курса. Дальнейшие рекомендации.</a></li>
<li><a title="Интернет-магазин на MODx" href="http://i--gu.ru/shopkeeper">Shopkeeper - Интернет-магазин на MODx</a></li>
<li><a title="Устанавливаем форум на MODx Evolution" href="http://i--gu.ru/phpbb-i-modxbb">phpBB и MODxBB - Устанавливаем форум на MODx Evolution</a></li>
<li><a title="Изменяем внешний вид административной панели" href="http://i--gu.ru/managerwelcome">ManagerWelcome - Изменяем внешний вид административной панели</a></li>
<li><a title="Ditto и экстендер request" href="http://i--gu.ru/sortirovka-ditto">Сортировка документов - Ditto и экстендер request</a></li>
<li><a title="Модули, плагины, сниппеты" href="http://i--gu.ru/poleznyie-ssyilki">Полезные ссылки - Модули, плагины, сниппеты</a></li>
<li><a title="Ответы на популярные вопросы по MODx Evolution" href="http://i--gu.ru/sprashivali-otvechaem">Спрашивали? Отвечаем - Ответы на популярные вопросы по MODx Evolution</a></li>
</ul>
<h3>Уроки по созданию сайта от Виктора Ефимова</h3>
<ul>
<li><a title="Инструкция по созданию сайта на MODx. Урок 1 &mdash; Вступительный" href="http://efimov.ws/main/develop/modx/instrukcziya-po-sozdaniyu-sajta-urok1.html">Урок 1 &mdash; Вступительный</a></li>
<li><a title="Инструкция по созданию сайта на MODx. Урок 2 &mdash; Установка MODx CMS" href="http://efimov.ws/main/develop/modx/instrukcziya-po-sozdaniyu-sajta-urok-2.html">Урок 2 &mdash; Установка MODx CMS</a></li>
<li><a title="Инструкция по созданию сайта на MODx. Урок 3 &mdash; Первоначальная настройка системы" href="http://efimov.ws/main/develop/modx/instrukcziya-po-sozdaniyu-sajta-na-modx-3.html">Урок 3 &mdash; Первоначальная настройка системы</a></li>
<li><a title="Интеграция дизайна в систему управления" href="http://efimov.ws/main/develop/modx/instrukcziya-po-sozdaniyu-sajta-na-modx-urok-4.html">Урок 4 &mdash; Интеграция дизайна в систему управления</a></li>
<li><a title="Настройка шаблона, разбиение на чанки" href="http://efimov.ws/main/develop/modx/instrukcziya-po-sozdaniyu-sajta-na-modx-urok-5.html">Урок 5 &mdash; Настройка шаблона, разбиение на чанки</a></li>
<li><a title="Дерево документов и создание страниц" href="http://efimov.ws/main/develop/modx/sajt-na-modxsozdanie-stranicz.html">Урок 6 &mdash; Дерево документов и создание страниц</a></li>
<li><a title="Реализация динамического меню" href="http://efimov.ws/main/develop/modx/menu-wayfinder-MODx.html">Урок 7 &mdash; Реализация динамического меню</a></li>
<li><a title="Создание шаблонов и вывод содержимого страниц" href="http://efimov.ws/main/develop/modx/instrukcziya-MODx-urok-8.html">Урок 8 &mdash; Создание шаблонов и вывод содержимого страниц</a></li>
<li><a title="абота со специальными тегами MODx" href="http://efimov.ws/main/develop/modx/tags-MODx.html">Урок 9 &mdash; Работа со специальными тегами MODx</a></li>
<li><a title="Работа с визуальным редактором в MODx" href="http://efimov.ws/main/develop/modx/tinymce-set-modx.html">Урок 10 &mdash; Работа с визуальным редактором в MODx</a></li>
<li><a title="Реализация цепочки навигации &laquo;Хлебные крошки&raquo;. Сниппет Breadcrumbs" href="http://efimov.ws/main/develop/modx/breadcrumbs-MODx.html">Урок 11 &mdash; Реализация цепочки навигации &laquo;Хлебные крошки&raquo;</a></li>
<li><a title="Создание ленты новостей. Сниппет Ditto" href="http://efimov.ws/main/develop/modx/ditto-modx-newsline.html">Урок 12 &mdash; Создание ленты новостей. Сниппет Ditto</a></li>
<li><a title="Урок 13 &mdash; Постраничное разбиение новостной ленты" href="http://efimov.ws/main/develop/modx/MODx-pagination-Ditto.html">Урок 13 &mdash; Постраничное разбиение новостной ленты</a></li>
<li><a title="Урок 14 &mdash; TV параметры MODx. Добавление изображений ресурсам" href="http://efimov.ws/main/develop/modx/MODx-TV-parametrs.html">Урок 14 &mdash; TV параметры MODx. Добавление изображений ресурсам</a></li>
<li><a title="Урок 15 &mdash; Форма обратной связи в MODx. Сниппет eForm" href="http://efimov.ws/main/develop/modx/eForm-MODx.html">Урок 15 &mdash; Форма обратной связи в MODx. Сниппет eForm</a></li>
<li><a title="Урок 16 &mdash; Реализация вспомогательного меню на странице" href="http://efimov.ws/main/develop/modx/modx-wayfinder.html">Урок 16 &mdash; Реализация вспомогательного меню на странице</a></li>
<li><a title="Урок 17 &mdash; Вывод слайд-шоу на главной странице с помощью сниппета Ditto" href="http://efimov.ws/main/develop/modx/jQuery-gallery-with-MODx.html">Урок 17 &mdash; Вывод слайд-шоу на главной странице с помощью сниппета Ditto</a></li>
<li><a title="Урок 18 &mdash;  Вывод ключевых слов в MODx" href="http://efimov.ws/main/develop/modx/meta-tags-keywords-modx.html">Урок 18 &mdash; Вывод ключевых слов в MODx</a></li>
<li><a title="Урок 19 &mdash; Организация поиска по сайту. Сниппет AjaxSearch" href="http://efimov.ws/main/develop/modx/snippet-ajaxsearch-modx-poisk.html">Урок 19 &mdash; Организация поиска по сайту. Сниппет AjaxSearch</a></li>
<li><a title="Урок 19.1 &mdash;  Вывод изображения, прикрепленного с помощью TV параметра, в результатах поиска AjaxSearch" href="http://efimov.ws/main/develop/modx/img-tv-parametrs-ajaxsearch.html">Урок 19.1 &mdash; Вывод изображения, прикрепленного с помощью TV параметра, в результатах поиска AjaxSearch</a></li>
<li><a title="Урок 20 &mdash; Карта сайта для посетителей и поисковых машин" href="http://efimov.ws/main/develop/modx/sitemap-for-modx-xml.html">Урок 20 &mdash; Карта сайта для посетителей и поисковых машин</a></li>
<li><a title=" Урок 21 &mdash; Реализация галереи изображений" href="http://efimov.ws/main/develop/modx/gallery-modx.html">Урок 21 &mdash; Реализация галереи изображений</a></li>
<li><a title=" Урок 22 &mdash; Перенос готового MODx сайта на хостинг" href="http://efimov.ws/main/develop/modx/hosting-modx.html">Урок 22 &mdash; Перенос готового MODx сайта на хостинг</a></li>
<li><a title=" Урок 23 &mdash; Скачать готовый MODx сайт, соответствующий веб-стандартам" href="http://efimov.ws/main/develop/modx/skachat-gotovyij-modx-sajt.html">Урок 23 &mdash; Скачать готовый MODx сайт, соответствующий веб-стандартам</a></li>
</ul>
<h3>Уроки по созданию блога от Виктора Ефимова</h3>
<ul>
<li><a title="Вступительный урок по созданию блога на MODx" href="http://efimov.ws/main/develop/modx/sozdanie-bloga-na-modx-vstuplenie.html">Вступительный урок</a></li>
<li><a title="Установка и первоначальная настройка системы управления" href="http://efimov.ws/main/develop/modx/sozdanie-bloga-na-modx-ustanovka.html">Урок 1. Установка и первоначальная настройка системы управления</a></li>
<li><a title="Урок 2. Интеграция дизайна в систему управления" href="http://efimov.ws/main/develop/modx/sozdanie-bloga-na-modx-iintegracziya-dizajna-v-modx.html">Урок 2. Интеграция дизайна в систему управления</a></li>
<li><a title="Урок 3.  Реализация навигации и работа со специальными тегами MODx" href="http://efimov.ws/main/develop/modx/sozdanie-bloga-na-modx-menu-i-tegi-modx.html">Урок 3. Реализация навигации и работа со специальными тегами MODx</a></li>
<li><a title="Вывод анонсов заметок на страницах категорий" href="http://efimov.ws/main/develop/modx/sozdanie-bloga-na-modx-urok-4.html">Урок 4. Вывод анонсов заметок на страницах категорий</a></li>
<li><a title="Урок 5. Оформление правой колонки: облако тегов, случайные заметки" href="http://efimov.ws/main/develop/modx/modx-urok-oblako-tegov-sluchajnie-zametki.html">Урок 5. Оформление правой колонки: облако тегов, случайные заметки</a></li>
<li><a title="Создание блога на MODx. Урок 6 &mdash; Поиск по сайту, контактная форма, XML и HTML карты, RSS рассылка" href="http://efimov.ws/main/develop/modx/modx-blog-sitemap-forma-poisk.html">Урок 6. Поиск по сайту, контактная форма, XML и HTML карты, RSS рассылка</a></li>
<li><a title=" Создание блога на MODx. Урок 7 &mdash; Оформление внутренних страниц блога и подключение комментариев" href="http://efimov.ws/main/develop/modx/modx-blog-comments-page-inside.html">Урок 7. Оформление внутренних страниц блога и подключение комментариев</a></li>
<li><a title=" Создание блога на MODx. Урок 8 &mdash; Устранение дублирования контента, оформление футера и другие настройки" href="http://efimov.ws/main/develop/modx/sozdanie-bloga-na-modx-urok-8.html">Урок 8. Устранение дублирования контента, оформление футера и другие настройки</a></li>
</ul>
<h3>Статьи по разработке сайтов на MODX</h3>
<ul>
<li><a title="Разработка на MODx с нуля" href="http://modx.ru/blog/modx-development-from-scratch/">Разработка на MODx с нуля</a></li>
<li><a title="Подготовка к работе" href="http://modx.ru/blog/first-step-work-preparing/">Шаг 1: Подготовка к работе</a></li>
<li><a title="Импорт готового дизайна" href="http://modx.ru/blog/import-ready-design-modx/">Шаг 2: Импорт готового дизайна</a></li>
<li><a title="Организация структуры документов в MODx" href="http://modx.ru/blog/organization-structure-modx-documents/">Шаг 3: Организация структуры документов в MODx</a></li>
<li><a title="Программируем верхнее меню на MODx" href="http://modx.ru/blog/modx-programming-top-menu/">Шаг 4: Программируем верхнее меню на MODx</a></li>
<li><a title="Вывод содержимого активной страницы" href="http://modx.ru/blog/modx-page-content/">Шаг 5: Вывод содержимого активной страницы</a></li>
<li><a title="Добавление и вывод статей на сайте" href="http://modx.ru/blog/modx-adding-articles/">Шаг 6.1: Добавление и вывод статей на сайте</a></li>
<li><a title="Постраничное разбиение (навигация) статей" href="http://modx.ru/blog/modx-pagination/">Шаг 6.2: Постраничное разбиение (навигация) статей</a></li>
<li><a title="Использование @-привязки в TV-параметрах" href="http://modx.ru/blog/bindings-easy2/">Использование @-привязки в TV-параметрах</a></li>
<li><a title="О привязке форумов к MODx" href="http://modx.ru/blog/modx-forum/">О привязке форумов к MODx</a></li>
<li><a title="Исправление форума &quot;кривыми&quot; руками" href="http://modx.ru/blog/modx-forum-correction/">Исправление форума "кривыми" руками</a></li>
</ul>