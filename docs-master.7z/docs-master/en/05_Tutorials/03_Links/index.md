Полезные ссылки
-------------------------

[MODX.im](http://modx.im)  - Сообщество по MODX

[code.divandesign.ru](http://code.divandesign.ru) - Репозиторий студии «Диван.Дизайн».