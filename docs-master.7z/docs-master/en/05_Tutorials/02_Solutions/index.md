Various solutions to specific tasks that you can use on your sites.
