To debug a snippet, use the debug parameter.

Possible values: -2, -1, 0, 1, 2. 

1 - will only show SQL queries.
2 - the whole stack of working snippets (which chunks were used, what data was substituted, etc.) The minus only affects the position of the block with debugging information (more than zero - up to the results of the snippet, and less than zero - after).

Default value - 0. 