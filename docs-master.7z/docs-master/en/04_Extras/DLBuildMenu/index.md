
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<h3>DLBuildMenu: документация, параметры, шаблоны </h3>
Документация по сниппету DLBuildMenu для создания меню на MODx Evo.
