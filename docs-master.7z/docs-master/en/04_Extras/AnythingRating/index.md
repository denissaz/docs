
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<h3>AnythingRating: Голосование на MODX Evolution Рейтинг ресурсов. Голосование посетителей</h3>
AnythingRating сниппет позволяющий организовать на своем сайте голосование за любую группу ресурсов: статью фотографию комментарий.
