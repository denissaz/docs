
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<h3>ManagerManager Настройка внешнего вида панели управления сайтом</h3>
ManagerManager позволяет настраивать внешний вид страницы создания, редактирования ресурса в бэкэнде сайта.
