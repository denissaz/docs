Shopkeeper - Evolution Internet Store

Snippet displays two types of shopping basket (extended or simple). Message with order details can be emailed and sent to the Shopkeeper module (recommended). Additional parameters can be attached to goods for the user to select. The eForm snippet is required for creation of the order form.

## Install ##

... need more