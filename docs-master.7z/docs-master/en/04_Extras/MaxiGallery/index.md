
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<h3>MaxiGallery галерея на MODX Evolution </h3>
Один из самых популярных сниппетов, для организации галереи на MODX Evolution. Очень прост в использовании и легко устанавливается.
