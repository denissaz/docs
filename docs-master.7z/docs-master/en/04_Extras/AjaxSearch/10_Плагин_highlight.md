
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<h3>AjaxSearch: Плагины Highlight </h3> 
Плагины Highlight для выделения слов в результатах поиска при использования сниппета AjaxSearch.	
<br>
<p>Плагины предназначены для выделения в результатах поиска слов из поискового запроса.</p>
<h3 class="sub-header text-bold">Плагин searchHighlight</h3>
<p>Выделение между тегами <code>&lt;body&gt;&lt;/body&gt;</code></p>
<h3 class="sub-header text-bold">Плагин advSearchHighlight</h3>
<p>Выделение между тегами <code>&lt;!--start highlight--&gt; и &lt;!--end highlight--&gt;</code>. Возможно многократное использование на странице.</p>