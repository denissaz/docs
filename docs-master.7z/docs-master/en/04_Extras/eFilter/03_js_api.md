## calback

### afterFilterSend(msg)

### afterFilterComplete(_form)

beforeFilterSend(_form)


## Внимание
Для работы ajax форма и блок товаров не должны быть в самом корне документа тоесть body.
