
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<h3>Personalize Проверка на авторизованность пользователя </h3>
Сниппет для проверки авторизован ли веб-пользователь или менеджер.
