
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<h3>CodeMirror Подсветка кода на Evolution CMS </h3>
Подсветка кода в административной панели в чанках, сниппетах, модулях, шаблонах на Evolution CMS.
