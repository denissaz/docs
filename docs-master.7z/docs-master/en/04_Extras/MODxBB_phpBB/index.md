
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<h3>MODxBB и phpBB форума в MODX Evolution </h3>
Интеграция форума phpBB в MODX Evolution.
