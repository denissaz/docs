
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<h3>ListIndexer - форматированный списка ссылок документов </h3>
Сниппет для вывода форматированного списка ссылок на документы.
