
Author: <a href="https://github.com/Jako/">Jako</a>

multiTV is a package for MODX Evolution content management framework.

With this MODX Evolution package a new template variable type is introduced. The template variable could contain a sortable multi item list or a datatable.

The package contains three main parts

- a custom template variable displaying and editing a sortable multi item list or a datatable
- a snippet to display the value of the template variable
- a module to edit the content of custom database tables.

and some extras

- a PHx modifier
- a Ditto filter extender
- a snippet for old installations to update the template variable content to the new format introduced with version 1.4.11.
