
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<h3>GetField Возвращает параметры любого документа </h3>
Сниппет GetField возвращает поля и TV-параметры любого документа или его родителя до указанного количества уровней.
