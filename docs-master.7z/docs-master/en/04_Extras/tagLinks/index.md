
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<h3>Навигация по сайту с помощью тегов </h3>
Сниппет tagLinks предназначен для формирования списка ссылок для фильтрации документов по категориям.
