
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<h3>MetaX Сниппет MetaX. Автоматическая генерация HTML тегов Base, Meta и Link</h3>
Представляет собой сниппет который автоматически генерирует HTML теги base meta и link в заголовке вашего сайта.
