
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<h3>UltimateParent Возвращает родительский документ</h3>
Параметры и примеры использования сниппета UltimateParent Сниппет возвращает родительский документ.
