This section contains general information about the Evolution CMS. Basically, it will be useful to those who are new to the CMS. Although for professionals it is also a good resource of information.

If you want to understand what EVO has to offer, we recommend that you read everything in the order of these help pages. If you have any questions or the information seems insufficient to you, then it's best to contact the community. Based on your questions, we constantly improve our material, which means their quality depends on you.
